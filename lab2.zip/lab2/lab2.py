# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 20:14:19 2025

@author: ACER
"""
# Importar todas las librerías necesarias
import numpy as np
import matplotlib.pyplot as plt
import wfdb
from scipy.stats import gaussian_kde

# ---------------------- PRIMER CÓDIGO ---------------------- #
# Definir las señales h[n] y x[n]
h = np.array([5, 6, 0, 0, 6, 7, 7])
x = np.array([1, 0, 7, 3, 1, 5, 2, 5, 0, 6])

# Realizar la convolución
y = np.convolve(x, h, mode='full')

# Mostrar la señal resultante
print("Señal y[n]:", y)

# Graficar la señal resultante
plt.stem(np.arange(len(y)), y)
plt.title("Convolución de x[n] y h[n]")
plt.xlabel("n")
plt.ylabel("y[n]")
plt.grid(True)
plt.show()

# Parámetros
Ts = 1.25e-3  # Periodo de muestreo Ts en segundos
n = np.arange(0, 9)  # Rango de n de 0 a 8

# Señales x1 y x2
x1 = np.cos(2 * np.pi * 100 * n * Ts)  # x1[nTs] = cos(2*pi*100*n*Ts)
x2 = np.sin(2 * np.pi * 100 * n * Ts)  # x2[nTs] = sin(2*pi*100*n*Ts)

# Calcular la correlación cruzada
correlacion = np.correlate(x1, x2, mode='full')

# Valores de desplazamiento
m = np.arange(-len(x1)+1, len(x1))

# Mostrar la correlación cruzada
print("Correlación cruzada entre x1[n] y x2[n]:", correlacion)

# Graficar las señales y la correlación
plt.figure(figsize=(12, 6))

# Subgráfico 1: x1[n] y x2[n]
plt.subplot(1, 2, 1)
plt.stem(n, x1, label="x1[n]", basefmt=" ", linefmt="b-", markerfmt="bo")
plt.stem(n, x2, label="x2[n]", basefmt=" ", linefmt="r-", markerfmt="ro")
plt.title("Señales x1[n] y x2[n]")
plt.xlabel("n")
plt.ylabel("Amplitud")
plt.legend()
plt.grid(True)

# Subgráfico 2: Correlación entre x1[n] y x2[n]
plt.subplot(1, 2, 2)
plt.stem(m, correlacion, basefmt=" ", linefmt="g-", markerfmt="go")
plt.title("Correlación entre x1[n] y x2[n]")
plt.xlabel("Desplazamiento m")
plt.ylabel("Valor de correlación")
plt.grid(True)

# Mostrar gráficos
plt.tight_layout()
plt.show()

# Leer la señal
record = wfdb.rdrecord('Subject10_AccTempEDA')
senal = record.p_signal

# Seleccionar el primer canal si la señal es multidimensional
if senal.ndim > 1:
    senal = senal[:, 0]

# Graficar la señal
plt.figure(figsize=(10, 4))
plt.plot(senal)
plt.title('Señal Original')
plt.xlabel('Tiempo [s]')
plt.ylabel('Voltaje [mV]')
plt.grid(True)
plt.show()

# Calcular los estadísticos desde cero
def calcular_media(signal):
    suma = 0
    for X in signal:
        suma += X
    return suma / len(signal)

def calcular_varianza(signal, media):
    suma = 0
    for X in signal:
        suma += (X - media) ** 2
    return suma / len(signal)

def calcular_desviacion_estandar(signal):
    media = calcular_media(signal)
    varianza = calcular_varianza(signal, media)
    return np.sqrt(varianza)

def calcular_coeficiente_variacion(media, desviacion_estandar):
    return (desviacion_estandar / media) * 100

# Calcular los estadísticos manuales
media_manual = calcular_media(senal)
desviacion_estandar_manual = calcular_desviacion_estandar(senal)
coeficiente_variacion_manual = calcular_coeficiente_variacion(media_manual, desviacion_estandar_manual)

# Mostrar los resultados
print("Estadísticos calculados:")
print(f"Media: {media_manual}")
print(f"Desviación estándar: {desviacion_estandar_manual}")
print(f"Coeficiente de variación: {coeficiente_variacion_manual}%")

# Calcular estadísticos con las funciones predefinidas
media_predefinida = np.mean(senal)
desviacion_estandar_predefinida = np.std(senal)
coeficiente_variacion_predefinido = (np.std(senal) / np.mean(senal)) * 100

# Mostrar estadísticos
print("\nEstadísticos usando funciones predefinidas:")
print(f"Media: {media_predefinida}")
print(f"Desviación estándar: {desviacion_estandar_predefinida}")
print(f"Coeficiente de Variación: {coeficiente_variacion_predefinido}%")

# Graficar histograma y función de probabilidad (manual)
plt.figure(figsize=(10, 6))
plt.hist(senal, bins=30, density=True, edgecolor="black", alpha=0.7, label='Histograma (manual)')

x_manual = np.linspace(min(senal), max(senal), 1000)
pdf_manual = gaussian_kde(senal)
plt.plot(x_manual, pdf_manual(x_manual), color='blue', linewidth=2, label='PDF (manual)')

plt.title('Histograma y Función de probabilidad de la señal manual')
plt.xlabel('Tiempo (s)')
plt.ylabel('Voltaje (mV)')
plt.legend()
plt.grid(True)
plt.show()

# Graficar histograma y función de probabilidad (predefinida)
plt.figure(figsize=(10, 6))
n, bins, patches = plt.hist(senal, bins=30, density=True, edgecolor="black", alpha=0.7, label='Histograma (predefinido)')

pdf = gaussian_kde(senal)
x = np.linspace(min(senal), max(senal), 1000)
plt.plot(x, pdf(x), color='red', linewidth=2, label='PDF (predefinido)')

plt.title('Histograma y Función de probabilidad predefinida de la señal')
plt.xlabel('Tiempo (s)')
plt.ylabel('Voltaje (mV)')
plt.legend()
plt.grid(True)
plt.show()

# Función para calcular el SNR
def calcular_snr(senal, ruido):
    potencia_senal = np.mean(senal**2)  # Potencia de la señal
    potencia_ruido = np.mean(ruido**2)  # Potencia del ruido
    snr = 10 * np.log10(potencia_senal / potencia_ruido)  # SNR en dB
    return snr

# a. Contaminar la señal con ruido gaussiano y medir el SNR
ruido_gaussiano = np.random.normal(0, 0.1, len(senal))  # Ruido gaussiano (media=0, desviación=0.1)
senal_gaussiano = senal + ruido_gaussiano  # Señal contaminada con ruido gaussiano
snr_gaussiano = calcular_snr(senal, ruido_gaussiano)  # Calcular SNR

# Graficar la señal con ruido gaussiano
plt.figure(figsize=(10, 4))
plt.plot(senal_gaussiano)
plt.title(f'Señal con Ruido Gaussiano (SNR = {snr_gaussiano:.2f} dB)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

# b. Contaminar la señal con ruido impulso y medir el SNR
ruido_impulso = np.zeros(len(senal))  # Inicializar ruido impulso
indices_impulso = np.random.choice(len(senal), size=50, replace=False)  # 50 puntos aleatorios
ruido_impulso[indices_impulso] = np.random.uniform(-1, 1, size=50)  # Ruido impulso
senal_impulso = senal + ruido_impulso  # Señal contaminada con ruido impulso
snr_impulso = calcular_snr(senal, ruido_impulso)  # Calcular SNR

# Graficar la señal con ruido impulso
plt.figure(figsize=(10, 4))
plt.plot(senal_impulso)
plt.title(f'Señal con Ruido Impulso (SNR = {snr_impulso:.2f} dB)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

# c. Contaminar la señal con ruido tipo artefacto y medir el SNR
ruido_artefacto = 0.5 * np.sin(2 * np.pi * 0.01 * np.arange(len(senal)))  # Ruido sinusoidal (artefacto)
senal_artefacto = senal + ruido_artefacto  # Señal contaminada con ruido artefacto
snr_artefacto = calcular_snr(senal, ruido_artefacto)  # Calcular SNR

# Graficar la señal con ruido artefacto
plt.figure(figsize=(10, 4))
plt.plot(senal_artefacto)
plt.title(f'Señal con Ruido Tipo Artefacto (SNR = {snr_artefacto:.2f} dB)')
plt.xlabel('Muestras')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()

# Mostrar los valores de SNR
print(f"SNR con ruido gaussiano: {snr_gaussiano:.2f} dB")
print(f"SNR con ruido impulso: {snr_impulso:.2f} dB")
print(f"SNR con ruido tipo artefacto: {snr_artefacto:.2f} dB")

# ---------------------- SEGUNDO CÓDIGO ---------------------- #
# Leer la señal
senal = wfdb.rdrecord("Subject10_AccTempEDA")
senal_data = senal.p_signal
frecuencia_muestreo = senal.fs

if frecuencia_muestreo is None:
    raise ValueError("La frecuencia de muestreo no está definida en el archivo.")

# Calcular estadísticas
media = np.mean(senal_data)
desviacion = np.std(senal_data)
coef_variacion = (desviacion / media) * 100

# Mostrar resultados
print(f"Media: {media}")
print(f"Desviación estándar: {desviacion}")
print(f"Coeficiente de Variación: {coef_variacion}%")
print(f"Frecuencia de muestreo: {frecuencia_muestreo} Hz")

# Graficar histograma
plt.figure(figsize=(10, 6))
plt.hist(senal_data, bins=30, density=True, edgecolor="black", alpha=0.7, label='Histograma')
plt.title("Histograma y Función de probabilidad de la señal")
plt.xlabel("Valores de la señal")
plt.ylabel("Frecuencia")
plt.legend()
plt.grid(True)
plt.show()

# ---------------------- TRANSFORMADA DE FOURIER ---------------------- #
# Calcular la Transformada de Fourier
N = len(senal_data)  # Número total de muestras
frequencias = np.fft.fftfreq(N, d=1/frecuencia_muestreo)  # Eje de frecuencias
TF = np.fft.fft(senal_data)  # Transformada de Fourier

# Calcular la Densidad Espectral de Potencia (PSD)
PSD = np.abs(TF)**2 / N  # Normalización

# Graficar la Transformada de Fourier (Magnitud)
plt.figure(figsize=(12, 5))
plt.plot(frequencias[:N//2], np.abs(TF[:N//2]))  # Solo la mitad positiva
plt.title("Transformada de Fourier de la Señal")
plt.xlabel("Frecuencia (Hz)")
plt.ylabel("Magnitud")
plt.grid()
plt.show()

# Graficar la Densidad Espectral de Potencia (PSD)
plt.figure(figsize=(12, 5))
plt.plot(frequencias[:N//2], PSD[:N//2])  # Solo la mitad positiva
plt.title("Densidad Espectral de Potencia (PSD)")
plt.xlabel("Frecuencia (Hz)")
plt.ylabel("Potencia")
plt.grid()
plt.show()

